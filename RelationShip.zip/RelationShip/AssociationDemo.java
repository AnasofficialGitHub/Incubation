package animalsabstract;
import java.util.*;
public class AssociationDemo {
	public static void main(String[] args) {
		Student s1 = new Student("Aslam",21,"8018");
		Student s2 = new Student("Arshath",21,"8019");
		Professor sb = new Professor();
		sb.view(s1);
		sb.view(s2);
	}

}
class Student
{
	String name;
	int age;
	String rollno;
	public Student(String name,int age,String rollno) 
	{
		this.name=name;
		this.age=age;
		this.rollno=rollno;
	}
	public String getInfo()
	{
		return "Name :"+name+" age : "+age+" rollno : "+rollno;
	}
}
class staff
{

}
class Professor
{
	public void view (Student s)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a roll no : ");
		String rolln=sc.next();
		if(s.rollno.equals(rolln))
		{
			System.out.println(s.getInfo());
		}
	}
}
