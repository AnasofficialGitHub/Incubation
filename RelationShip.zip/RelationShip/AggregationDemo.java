package animalsabstract;

public class AggregationDemo 
{
	public static void main(String[] args) 
	{
		Dependent father = new Dependent("Ahmed","Male");
		Employee emp = new Employee("Suhail","1001",father);
		emp.display();
		
	}

}
class Dependent
{
	String dependentname;
	String dependentgender;
	public Dependent(String dependentname, String dependentgender) {
		this.dependentname = dependentname;
		this.dependentgender = dependentgender;
	}
	public void displayDependent()
	{
		System.out.println("Dependent name : "+dependentname+" "+"dependent Gender "+dependentgender);
	}
	
	
}
class Employee
{
	String name;
	String empid;
	Dependent father;
	public Employee(String name,String empid,Dependent dependent)
	{
		this.name=name;
		this.empid=empid;
		father =dependent;
	}
	public void display()
	{
		System.out.println("Name : "+name+" empid : "+empid+" dependent name : "+father.dependentname+" dependent gender : "+father.dependentgender);
	}
}
