package animalsabstract;

public class CompositionDemo {
	public static void main(String[] args) 
	{
		Employees emp = new Employees("Suhail","1001","Ahmed","Male");
		emp.display();
		
	}

}
class Dependents
{
	String dependentname;
	String dependentgender;
	public Dependents(String dependentname, String dependentgender) {
		this.dependentname = dependentname;
		this.dependentgender = dependentgender;
	}
	public void displayDependent()
	{
		System.out.println("Dependent name : "+dependentname+" "+"dependent Gender "+dependentgender);
	}
	
	
}
class Employees
{
	String name;
	String empid;
	Dependent father;
	public Employees(String name,String empid,String dname,String dgender)
	{
		this.name=name;
		this.empid=empid;
		father =new Dependent(dname,dgender);
	}
	public void display()
	{
		System.out.println("Name : "+name+" empid : "+empid+" dependent name : "+father.dependentname+" dependent gender : "+father.dependentgender);
	}
}
